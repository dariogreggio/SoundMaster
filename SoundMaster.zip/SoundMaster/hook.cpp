// ObjectWindows - (C) Copyright 1992 by Borland International

#include <owl.h>

HANDLE hInst,hHook;
FARPROC hHookProc;

DWORD _export FAR PASCAL HookProc(int code, int wParam, long lParam) {
	if(wParam == 'W')
		PostMessage(0x1b4c,WM_CHAR,'I',0);
	if(1) {
		CallNextHookEx(hHook, code, wParam, lParam);
    }
  }
 
// Define a class derived from TApplication
class THelloApp :public TApplication
{
public:
  THelloApp(LPSTR AName, HINSTANCE hInstance, HINSTANCE hPrevInstance,
    LPSTR lpCmdLine, int nCmdShow)
    : TApplication(AName, hInstance, hPrevInstance, lpCmdLine, nCmdShow) {};
  virtual void InitMainWindow();
};

// Construct the THelloApp's MainWindow data member
void THelloApp::InitMainWindow()
{
	MainWindow = new TWindow(NULL, "Hook!");
	hHookProc=MakeProcInstance((FARPROC)HookProc,hInst);
	hHook=SetWindowsHookEx(WH_KEYBOARD,hHookProc,hInst,GetWindowTask(0x1b4c));
}

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
  LPSTR lpCmdLine, int nCmdShow)
{
  THelloApp HelloApp ("HelloApp", hInstance, hPrevInstance,
		lpCmdLine, nCmdShow);
  hInst=hInstance;
	HelloApp.Run();
  UnhookWindowsHookEx(hHook);
	FreeProcInstance(hHookProc);
	return HelloApp.Status;
}
