#include <stdio.h>
#include <windows.h>
#include <mmsystem.h>
#include <commdlg.h>
#include "afxres.h"
#include "soundmaster.h"
#include "soundmrc.h"

#define IDM_ABOUT     1001
#define MAX_SOUNDS 12

#if defined (WIN32)
	#define IS_WIN32 TRUE
#else
	#define IS_WIN32 FALSE
#endif
#define IS_NT      IS_WIN32 && (BOOL)(GetVersion() < 0x80000000)
#define IS_WIN32S  IS_WIN32 && (BOOL)(!(IS_NT) && (LOBYTE(LOWORD(GetVersion()))<4))
#define IS_WIN95 (BOOL)(!(IS_NT) && !(IS_WIN32S)) && IS_WIN32

char *APP_ID="Soundmaster";
char *APP_INI="Soundmaster.ini";
char *APP_IDs="WAVHOOK";
char *APP_Alert="Attenzione: chiudendo il programma si interromper� la gestione suoni!";
HANDLE hInst,hHook;
HWND hWnd,hStatusBar;
HFONT hFont;
HANDLE hAccTable;
WAVEHDR *OWaveHdr,*IWaveHdr,*OWaveHdr2,*IWaveHdr2;
HWAVEOUT hWaveOut;
HWAVEIN hWaveIn;
char buffer[256],WAVFiles[3][MAX_SOUNDS][128];
HANDLE hMem1p,hMem2p,hMem1r,hMem2r,hMem3,hMem4,hMem5,hMem6;
LPSTR pMem1p,pMem2p,pMem1r,pMem2r;
extern DWORD IRecNo,IFirstRecord,ORecNo;
int BaseAddress=0x300;
int CardOk,UseCard,UseTimer,TimerTime,TimerCnt,bTimer2,bVocoder;
int UseCTRL,bBanco,bVocoderMode=1;
int SuonaAuto,nextTimer;
int WAVMode=SND_ASYNC,bEffects=0;

ATOM MyRegisterClass(CONST WNDCLASS*);
BOOL InitApplication(HINSTANCE);
BOOL InitInstance(HINSTANCE, int);
LRESULT CALLBACK AppWndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK About(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK OpzioniDlg(HWND, UINT, WORD, LONG);
LRESULT CALLBACK VocoderDlg(HWND, UINT, WORD, LONG);

static int CheckCard(int BaseAddress) {
  int i;

	i=(~_inp(BaseAddress)) & 0xa;   // ne controllo 2...
	i >>= 1;
  return i;
	}


HOOKPROC CALLBACK HookProc(int code, WPARAM wParam, LPARAM lParam);
int FAR PASCAL HookInit(HANDLE myHook,char WAVFiles[MAX_SOUNDS][256],int n, int WAVMode, int UseCTRL);
int FAR PASCAL WritePrivateProfileInt(char *, char *, int ,char *);


int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
	MSG msg;						 /* message 				 */
	int i;
	long l;
	BOOL bMsgAvail;

    // Win32 will always set hPrevInstance to NULL...
	if(!hPrevInstance) {
		// Perform instance initialization:
		if(!InitApplication(hInstance)) {
			return (FALSE);
			}
		}

	// Perform application initialization:
	if(!InitInstance(hInstance, nCmdShow)) {
		return (FALSE);
		}

	hInst = hInstance;      /* Saves the current instance      */
	
	hHook=SetWindowsHookEx(WH_KEYBOARD,HookProc,hInst,0);
 	HookInit(hHook,WAVFiles[bBanco],MAX_SOUNDS,WAVMode,UseCTRL);

	ShowWindow(hWnd, nCmdShow);       /* Shows the window      */
	PostMessage(hWnd,WM_ENTERIDLE,0,0l);

	while(TRUE) {
	  if(UseCard) {
			if(!CardOk) {
			  if(i=CheckCard(BaseAddress)) {
//			  wsprintf(buffer,"%x",i);
//			  MessageBox(hWnd,buffer,NULL,MB_OK);
			    CardOk=TRUE;
// modif. per il Salone del Libro 17/5/96...
// una volta attiva timer, un'altra lo spegne (+ rel�)
					if(i & 1)
			      PlaySound(WAVFiles[bBanco][10],NULL,SND_SYNC | SND_NODEFAULT);
					else {
						UseTimer=!UseTimer;
						if(!UseTimer)
						  _outp(BaseAddress,1);
				      PlaySound(WAVFiles[bBanco][0],NULL,SND_SYNC | SND_NODEFAULT);
						}
					}
				}
			else {
			  if(!CheckCard(BaseAddress)) 
			    CardOk=0;
			  }
		  }
		  
		bMsgAvail=PeekMessage(&msg,NULL,0,0,PM_REMOVE /*| PM_NOYIELD*/);

		if(bMsgAvail) {
			if(msg.message == WM_QUIT)
		  	break;
			if(!TranslateAccelerator(msg.hwnd,hAccTable,&msg)) {
				TranslateMessage(&msg); 	 /* Translates virtual key codes			 */
				DispatchMessage(&msg);		 /* Dispatches message to window			 */
				}
			}
		}

  UnhookWindowsHookEx(HookProc);
	return (msg.wParam);      /* Returns the value from PostQuitMessage */
	}

long FAR PASCAL AppWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
	int wmId, wmEvent;
	PAINTSTRUCT ps;
	HFONT hOldFont;
	int i,j,k;
	long l,l1;
	HDC hDC;
	LPSTR p;
	MSG msg;
	HMENU hMenu;
	OPENFILENAME ofn;
	char szDirName[128];
	char szFileTitle[128], szExt[4];
	UINT  cbString;
	char  chReplace;    /* string separator for szFilter */
	char  szFilter[128],myBuf[128];
	HANDLE hMem,hFile;
	char *pMem;
	POINT pnt;
	STARTUPINFO si;

	switch (message) {
   	case WM_COMMAND:
			wmId    = LOWORD(wParam); // Remember, these are...
			wmEvent = HIWORD(wParam); // ...different for Win32!

			//Parse the menu selections:
			switch(wmId) {
			  case ID_APP_ABOUT:
				/* Draw and handle messages for the "About..." Dialog */
  				DialogBox(hInst,MAKEINTRESOURCE(1),hWnd,(DLGPROC)About);
					break;
			  case ID_APP_EXIT:
					goto esciprg;
					break;
			  case ID_FILE_OPEN1:
			  case ID_FILE_OPEN2:
			  case ID_FILE_OPEN3:
			  case ID_FILE_OPEN4:
			  case ID_FILE_OPEN5:
			  case ID_FILE_OPEN6:
			  case ID_FILE_OPEN7:
			  case ID_FILE_OPEN8:
			  case ID_FILE_OPEN9:
			  case ID_FILE_OPEN10:
			  case ID_FILE_OPEN11:
			  case ID_FILE_OPEN12:
//					strcpy(szFile,"*.wav");
					strcpy(szExt,"wav");
									
					strcpy(szFilter,"File wave (*.WAV)|*.wav|Tutti i file|*.*");
					chReplace = '|'; /* retrieve wildcard */
					
					for(i=0; szFilter[i]; i++) {
				    if(szFilter[i] == chReplace)
				      szFilter[i]=0;
						}
		      szFilter[i+1]=0;
		
					/* Set all structure members to zero. */
					memset(&ofn, 0, sizeof(OPENFILENAME));
						
					ofn.lStructSize = sizeof(OPENFILENAME);
					ofn.hwndOwner = hWnd;
					ofn.lpstrFilter = szFilter;
					ofn.nFilterIndex = 1;
					ofn.lpstrFile= WAVFiles[bBanco][wParam-ID_FILE_OPEN1];
					ofn.nMaxFile = 128;  //256
					ofn.lpstrFileTitle = szFileTitle;
					ofn.nMaxFileTitle = sizeof(szFileTitle);
					ofn.lpstrInitialDir = szDirName;
					ofn.lpstrDefExt= szExt;
					ofn.hInstance= hInst;
					ofn.Flags = OFN_HIDEREADONLY | OFN_FILEMUSTEXIST;

					if(GetOpenFileName(&ofn)) {
						strcpy(WAVFiles[bBanco][wParam-ID_FILE_OPEN1],ofn.lpstrFile);
           	HookInit(hHook,WAVFiles[bBanco],MAX_SOUNDS,WAVMode,UseCTRL);
           	InvalidateRect(hWnd,NULL,TRUE);
						}
					break;
			  case ID_SUONA1:
			  case ID_SUONA2:
			  case ID_SUONA3:
			  case ID_SUONA4:
			  case ID_SUONA5:
			  case ID_SUONA6:
			  case ID_SUONA7:
			  case ID_SUONA8:
			  case ID_SUONA9:
			  case ID_SUONA10:
			  case ID_SUONA11:
			  case ID_SUONA12:
					PlaySound(WAVFiles[bBanco][LOWORD(wParam)-ID_SUONA1],NULL,WAVMode | SND_NODEFAULT);
					break;
			  case ID_SUONA99:
					PlaySound(NULL,NULL,WAVMode);
					break;
			  case ID_SUONA_AUTO:
					SuonaAuto=!SuonaAuto;
					if(SuonaAuto)
  		      nextTimer=(rand() % 9) + 1;
					break;
			  case ID_SUONAB1:
					bBanco=0;
					goto upd_banco;
					break;
			  case ID_SUONAB2:
					bBanco=1;
					goto upd_banco;
					break;
			  case ID_SUONAB3:
					bBanco=2;
upd_banco:
					InvalidateRect(hWnd,NULL,TRUE);
			 	  HookInit(hHook,WAVFiles[bBanco],MAX_SOUNDS,WAVMode,UseCTRL);
  				break;
			  case ID_FILE_VOCODERATTIVO:
					bVocoder=!bVocoder;
upd_vocoder:
					if(bVocoder) {
						inPrepare(1,&hWaveIn);
						outPrepare(1,&hWaveOut);
					  }
					else {
						inPrepare(0,&hWaveIn);
						outPrepare(0,&hWaveOut);
					  }
					break;
			  case ID_FILE_OPZIONI:
  				if(DialogBox(hInst,MAKEINTRESOURCE(2),hWnd,(FARPROC)OpzioniDlg)) {
				 	  HookInit(hHook,WAVFiles[bBanco],MAX_SOUNDS,WAVMode,UseCTRL);
						if(!UseTimer)
							  _outp(BaseAddress,1);
						}
					break;
			  case ID_FILE_VOLUME:
//					GetStartupInfo(&si);
//					CreateProcess(NULL,"sndvol32",NULL,NULL,0,0,NULL,NULL,&si,NULL);
					WinExec("sndvol32",SW_SHOW);
/*					{
		SHELLEXECUTEINFO sei;

		ZeroMemory(&sei,sizeof(SHELLEXECUTEINFO));
		sei.cbSize = sizeof( SHELLEXECUTEINFO );		// Set Size
		sei.lpVerb = TEXT( "open" );					// Set Verb
		sei.lpFile ="sndvol32.exe";							// Set Target To Open
		sei.nShow = SW_SHOWNORMAL;						// Show Normal

		ShellExecuteEx(&sei);
		}*/
					break;
			  case ID_VOCODER_PARAMETRI:
  				if(DialogBox(hInst,MAKEINTRESOURCE(IDD_VOCOD_PARMS),hWnd,(FARPROC)VocoderDlg)) {
					  }
					break;
				default:
					return DefWindowProc(hWnd, message, wParam, lParam);
				}
			break;

   	case WM_INITMENU:
   	  CheckMenuItem((HMENU)wParam,ID_SUONA_AUTO,SuonaAuto ? MF_CHECKED : MF_UNCHECKED);
   	  CheckMenuItem((HMENU)wParam,ID_FILE_VOCODERATTIVO,bVocoder ? MF_CHECKED : MF_UNCHECKED);
   	  CheckMenuItem((HMENU)wParam,ID_SUONAB1,bBanco==0 ? MF_CHECKED : MF_UNCHECKED);
   	  CheckMenuItem((HMENU)wParam,ID_SUONAB2,bBanco==1 ? MF_CHECKED : MF_UNCHECKED);
   	  CheckMenuItem((HMENU)wParam,ID_SUONAB3,bBanco==2 ? MF_CHECKED : MF_UNCHECKED);
			break;
			
		case WM_CREATE: 						/* message: window being created */
		  hMem1p=GlobalAlloc(GMEM_MOVEABLE | GMEM_SHARE,25000);
		  pMem1p=GlobalLock(hMem1p);
		  hMem2p=GlobalAlloc(GMEM_MOVEABLE | GMEM_SHARE,25000);
		  pMem2p=GlobalLock(hMem2p);
		  hMem1r=GlobalAlloc(GMEM_MOVEABLE | GMEM_SHARE,25000);
		  pMem1r=GlobalLock(hMem1r);
		  hMem2r=GlobalAlloc(GMEM_MOVEABLE | GMEM_SHARE,25000);
		  pMem2r=GlobalLock(hMem2r);
		  hMem3=GlobalAlloc(GMEM_SHARE | GMEM_MOVEABLE,sizeof(WAVEHDR));
		  IWaveHdr=(LPWAVEHDR)GlobalLock(hMem3);
		  hMem4=GlobalAlloc(GMEM_SHARE | GMEM_MOVEABLE,sizeof(WAVEHDR));
		  IWaveHdr2=(LPWAVEHDR)GlobalLock(hMem4);
		  hMem5=GlobalAlloc(GMEM_SHARE | GMEM_MOVEABLE,sizeof(WAVEHDR));
		  OWaveHdr=(LPWAVEHDR)GlobalLock(hMem5);
		  hMem6=GlobalAlloc(GMEM_SHARE | GMEM_MOVEABLE,sizeof(WAVEHDR));
		  OWaveHdr2=(LPWAVEHDR)GlobalLock(hMem6);
			hFont=CreateFont(12,6,0,0,400,0,0,0,
				ANSI_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,
				DEFAULT_QUALITY,DEFAULT_PITCH | FF_MODERN, (LPSTR)"Arial");
			BaseAddress=GetPrivateProfileInt(APP_ID,"Porta",0x300,APP_INI);
			TimerTime=GetPrivateProfileInt(APP_ID,"TimerTime",5,APP_INI);
			UseCTRL=GetPrivateProfileInt(APP_ID,"UsaALT",0,APP_INI);
			UseCard=GetPrivateProfileInt(APP_ID,"UsaScheda",0,APP_INI);
			UseTimer=GetPrivateProfileInt(APP_ID,"UsaTimer",0,APP_INI);
			WAVMode=GetPrivateProfileInt(APP_ID,"WAVMode",SND_ASYNC,APP_INI);
			bVocoder=GetPrivateProfileInt(APP_ID,"Vocoder",0,APP_INI);
			for(j=0; j<3; j++) {
 			  wsprintf(myBuf,"BancoSuoni %d",j);
  			for(i=0; i<MAX_SOUNDS; i++) {
    			wsprintf(buffer,"Suono %d",i);
		  	  GetPrivateProfileString(myBuf,buffer,"",WAVFiles[j][i],128,APP_INI);
				  }
			  }
			SetTimer(hWnd,1,1000/SAMPLE_ACCU,NULL);  
			goto upd_vocoder;
			break;

		case WM_PAINT:
			hDC=BeginPaint(hWnd,&ps);
			hOldFont=SelectObject(hDC,hFont);
			SetBkColor(hDC,RGB(192,192,192));
			for(i=0; i<MAX_SOUNDS; i++) {
  			wsprintf(buffer,"F%d:",i+1);
			  TextOut(hDC,10,10+i*12,buffer,strlen(buffer));
  			wsprintf(buffer,"%s",WAVFiles[bBanco][i]);
			  TextOut(hDC,60,10+i*12,buffer,strlen(buffer));
			  }
			SelectObject(hDC,hOldFont);
			EndPaint(hWnd,&ps);
			return DefWindowProc(hWnd, message, wParam, lParam);
			break;

		case WM_TIMER:
			if(hWaveIn) {
				inWave(&IRecNo,&IFirstRecord,hWaveIn,IWaveHdr,IWaveHdr2,pMem1r,pMem2r);
				if(!(IRecNo & 1))
					ModificaWave(pMem1p,pMem1r);
				else
					ModificaWave(pMem2p,pMem2r);
				if(hWaveOut) {
					outWave(&ORecNo,0,hWaveOut,OWaveHdr,OWaveHdr2,pMem1p,pMem2p);
				  }
			  }
		  TimerCnt++;
		  if(UseTimer) {
		    if(TimerCnt>=TimerTime) {
		      TimerCnt=0;
		      PlaySound(WAVFiles[bBanco][11],NULL,SND_ASYNC);
			    bTimer2=0;
		      }
				else {
					if(!bTimer2)
						bTimer2=1;
					}
			  _outp(BaseAddress,bTimer2 & 1);
		    }
		  else if(SuonaAuto) {
		    if(TimerCnt>=nextTimer) {
		      TimerCnt=0;
					if(bEffects) {
						hFile=CreateFile(WAVFiles[bBanco][rand() % 10],GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL | FILE_FLAG_SEQUENTIAL_SCAN,NULL);
						l=_filelength(hFile);
						hMem=GlobalAlloc(GPTR,l);
						pMem=GlobalLock(hMem);
						wsprintf(buffer,"createfile: %d; mem %lx; len file: %ld",hFile,hMem,l);
						MessageBox(hWnd,buffer,NULL,MB_OK);
  		      ReadFile(hFile,pMem,l,&l1,NULL);
						CloseHandle(hFile);
						CreaEffetti(pMem,l,1);
						PlaySound(pMem,NULL,SND_MEMORY | SND_ASYNC);
						GlobalUnlock(hMem);
						GlobalFree(hMem);
					  }
					else {
						j=0;
						do {
							i=rand() % 10;
						  if(*WAVFiles[bBanco][i]) {
						    PlaySound(WAVFiles[bBanco][i],NULL,SND_ASYNC | SND_NODEFAULT);
							  break;
							  }
							j++;
						  } while(j<10);
					  }
 		      nextTimer=(rand() % 9) + 1;
  		    }
		    }
		    
			break;

		case WM_CLOSE:
esciprg:          
			if(MessageBox(hWnd,APP_Alert,APP_ID,MB_OKCANCEL | MB_ICONHAND | MB_DEFBUTTON2) == IDOK) {
				DeleteObject(hFont);
				KillTimer(hWnd,1);
				for(j=0; j<3; j++) {
  			  wsprintf(myBuf,"BancoSuoni %d",j);
				  for(i=0; i<MAX_SOUNDS; i++) {
	  			  wsprintf(buffer,"Suono %d",i);
				    WritePrivateProfileString(myBuf,buffer,WAVFiles[j][i],APP_INI);
					  }
				  }
				WritePrivateProfileInt(APP_ID,"Porta",BaseAddress,APP_INI);
				WritePrivateProfileInt(APP_ID,"TimerTime",TimerTime,APP_INI);
				WritePrivateProfileInt(APP_ID,"UsaALT",UseCTRL,APP_INI);
				WritePrivateProfileInt(APP_ID,"UsaScheda",UseCard,APP_INI);
				WritePrivateProfileInt(APP_ID,"UsaTimer",UseTimer,APP_INI);
				WritePrivateProfileInt(APP_ID,"WAVMode",WAVMode,APP_INI);
				WritePrivateProfileInt(APP_ID,"Vocoder",bVocoder,APP_INI);
				GlobalUnlock(hMem1p);
				GlobalFree(hMem1p);
				GlobalUnlock(hMem2p);
				GlobalFree(hMem2p);
				GlobalUnlock(hMem1r);
				GlobalFree(hMem1r);
				GlobalUnlock(hMem2r);
				GlobalFree(hMem2r);
				GlobalUnlock(hMem3);
				GlobalFree(hMem3);
				GlobalUnlock(hMem4);
				GlobalFree(hMem4);
				GlobalUnlock(hMem5);
				GlobalFree(hMem5);
				GlobalUnlock(hMem6);
				GlobalFree(hMem6);
			  DestroyWindow(hWnd);
			  }
			return 0l;
			break;

		case WM_NCRBUTTONUP: // RightClick on windows non-client area...
			if(IS_WIN95 && SendMessage(hWnd, WM_NCHITTEST, 0, lParam) == HTSYSMENU) {
					// The user has clicked the right button on the applications
					// 'System Menu'. Here is where you would alter the default
					// system menu to reflect your application. Notice how the
					// explorer deals with this. For this app, we aren't doing
					// anything
				return (DefWindowProc(hWnd, message, wParam, lParam));
				}
			else {
				// Nothing we are interested in, allow default handling...
				return (DefWindowProc(hWnd, message, wParam, lParam));
				}
			break;

	  case WM_RBUTTONDOWN: // RightClick in windows client area...
      pnt.x = LOWORD(lParam);
      pnt.y = HIWORD(lParam);
      ClientToScreen(hWnd, (LPPOINT) &pnt);
		// This is where you would determine the appropriate 'context'
		// menu to bring up. Since this app has no real functionality,
		// we will just bring up the 'Help' menu:
      hMenu = GetSubMenu(GetSubMenu(GetMenu(hWnd),1),0);
      if(hMenu) {
        TrackPopupMenu (hMenu, 0, pnt.x, pnt.y, 0, hWnd, NULL);
        }
			else {
				// Couldn't find the menu...
        MessageBeep(0);
        }
      break;

		case WM_QUERYENDSESSION:
			if(MessageBox(hWnd,APP_Alert,APP_ID,MB_OKCANCEL | MB_ICONSTOP | MB_DEFBUTTON2) == IDOK)
			  return 1l;
			else 
			  return 0l;
			break;

		case WM_DESTROY:
		  PostQuitMessage(0);
			break;

		default:
			return (DefWindowProc(hWnd, message, wParam, lParam));
		}
	return 0;

	}


ATOM MyRegisterClass(CONST WNDCLASS *lpwc) {
	HANDLE  hMod;
	FARPROC proc;
	WNDCLASSEX wcex;

	hMod = GetModuleHandle ("USER32");
	if (hMod != NULL) {

#if defined (UNICODE)
		proc = GetProcAddress (hMod, "RegisterClassExW");
#else
		proc = GetProcAddress (hMod, "RegisterClassExA");
#endif

		if (proc != NULL) {

			wcex.style         = lpwc->style;
			wcex.lpfnWndProc   = lpwc->lpfnWndProc;
			wcex.cbClsExtra    = lpwc->cbClsExtra;
			wcex.cbWndExtra    = lpwc->cbWndExtra;
			wcex.hInstance     = lpwc->hInstance;
			wcex.hIcon         = lpwc->hIcon;
			wcex.hCursor       = lpwc->hCursor;
			wcex.hbrBackground = lpwc->hbrBackground;
            			wcex.lpszMenuName  = lpwc->lpszMenuName;
			wcex.lpszClassName = lpwc->lpszClassName;

			// Added elements for Windows 95:
			wcex.cbSize = sizeof(WNDCLASSEX);
			wcex.hIconSm = LoadIcon(wcex.hInstance, "SMALL");
			
			return (*proc)(&wcex);//return RegisterClassEx(&wcex);
		}
	}
	return (RegisterClass(lpwc));
}


//
//  FUNCTION: InitApplication(HANDLE)
//
//  PURPOSE: Initializes window data and registers window class 
//
//  COMMENTS:
//
//       In this function, we initialize a window class by filling out a data
//       structure of type WNDCLASS and calling either RegisterClass or 
//       the internal MyRegisterClass.
//
BOOL InitApplication(HINSTANCE hInstance) {
    WNDCLASS  wc;
    HWND      hwnd;

    // Win32 will always set hPrevInstance to NULL, so lets check
    // things a little closer. This is because we only want a single
    // version of this app to run at a time
    hwnd = FindWindow (APP_IDs, NULL);
    if (hwnd) {
        // We found another version of ourself. Lets defer to it:
        if(IsIconic(hwnd)) {
          ShowWindow(hwnd, SW_RESTORE);
					}
        SetForegroundWindow (hwnd);

        // If this app actually had any functionality, we would
        // also want to communicate any action that our 'twin'
        // should now perform based on how the user tried to
        // execute us.
        return FALSE;
        }

        // Fill in window class structure with parameters that describe
        // the main window.
	      wc.style         = 0;
        wc.lpfnWndProc   = (WNDPROC)AppWndProc;
        wc.cbClsExtra    = 0;
        wc.cbWndExtra    = 0;
        wc.hInstance     = hInstance;
        wc.hIcon         = LoadIcon (hInstance, "AppIcon1");
        wc.hCursor = LoadCursor(hInstance, "AppCursor");
        wc.hbrBackground = GetStockObject(LTGRAY_BRUSH);

        // Since Windows95 has a slightly different recommended
        // format for the 'Help' menu, lets put this in the alternate menu like this:
        if(IS_WIN95) {
					wc.lpszMenuName  = "IDR_MENU1";
					} 
				else {
					wc.lpszMenuName  = "IDR_MENU1";
					}
        wc.lpszClassName = APP_IDs;

        // Register the window class and return success/failure code.
        if(IS_WIN95) {
					return MyRegisterClass(&wc);
					}
				else {
					return RegisterClass(&wc);
        }
	}

BOOL InitInstance(HINSTANCE hInstance, int nCmdShow) {
	HWND hWnd;
	
	hInst = hInstance; // Store instance handle in our global variable

	hWnd = CreateWindow(APP_IDs,								/* window class 					 */
		APP_ID,						/* window name						 */
		WS_SYSMENU | WS_CAPTION	| WS_MINIMIZEBOX,
		CW_USEDEFAULT,CW_USEDEFAULT,
		500,300,
		NULL,           /* parent handle       */
		NULL,           /* menu or child ID      */
		hInstance,          /* instance        */
		NULL);            /* additional info       */


	if(!hWnd)
		return (FALSE);
	
 	hAccTable=LoadAccelerators(hInstance,MAKEINTRESOURCE(IDR_ACCELERATOR1));

	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	return (TRUE);
  }


LRESULT CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam) {
	int x,y,x1,y1;
	RECT dim;

	switch (message) {
		case WM_INITDIALOG:        /* message: initialize dialog box */
		  wsprintf(buffer,"Installato su %xH",BaseAddress);
		  SetDlgItemText(hDlg,IDS_ABOUT2,buffer);
			return (TRUE);

   	case WM_COMMAND:          /* message: received a command */
			if(wParam == IDOK) {       /* "OK" box selected?      */
	    	EndDialog(hDlg, FALSE);        /* Exits the dialog box      */
		    return (TRUE);
			  }
			else if(wParam==2) {
				MessageBox(hDlg,"Se trovate utile questo programma, mandate un contributo!!\nLiverpool (UK)\nadpm.to@inwind.it","Dario's Automation",MB_OK);
			  return (TRUE);
			  }
			break;
		}
	return (FALSE);           /* Didn't process a message    */
  }


LRESULT CALLBACK OpzioniDlg(HWND hDlg, unsigned message, WORD wParam, LONG lParam) {
	int x,y,x1,y1;
	RECT dim;

	switch(message) {
		case WM_INITDIALOG:
		  wsprintf(buffer,"%x",BaseAddress);
		  SetDlgItemText(hDlg,IDC_EDIT1,buffer);
		  SetDlgItemInt(hDlg,IDC_EDIT2,TimerTime,0);
		  CheckDlgButton(hDlg,IDC_CHECK1,UseCard);
		  CheckRadioButton(hDlg,IDC_RADIO1,IDC_RADIO2,UseCTRL ? IDC_RADIO2 : IDC_RADIO1);
		  CheckRadioButton(hDlg,IDC_RADIO3,IDC_RADIO4,WAVMode == SND_ASYNC ? IDC_RADIO4 : IDC_RADIO3);
		  CheckDlgButton(hDlg,IDC_CHECK2,UseTimer);
 		  EnableWindow(GetDlgItem(hDlg,IDC_EDIT1),UseCard);
 		  EnableWindow(GetDlgItem(hDlg,IDC_EDIT2),UseTimer);
			return (TRUE);

   	case WM_COMMAND:
			switch(wParam) {
			  case IDC_CHECK1:
    		  EnableWindow(GetDlgItem(hDlg,IDC_EDIT1),IsDlgButtonChecked(hDlg,IDC_CHECK1));
    		  return TRUE;
		  	  break;
			  case IDC_CHECK2:
    		  EnableWindow(GetDlgItem(hDlg,IDC_EDIT2),IsDlgButtonChecked(hDlg,IDC_CHECK2));
    		  return TRUE;
		  	  break;
			  case IDOK:
		  	  GetDlgItemText(hDlg,IDC_EDIT1,buffer,8);
	  		  sscanf(buffer,"%x",&BaseAddress);
		  	  TimerTime=GetDlgItemInt(hDlg,IDC_EDIT2,NULL,0);
	  		  UseCard=IsDlgButtonChecked(hDlg,IDC_CHECK1);
	  		  UseTimer=IsDlgButtonChecked(hDlg,IDC_CHECK2);
	  		  UseCTRL=IsDlgButtonChecked(hDlg,IDC_RADIO2);
	  		  WAVMode=IsDlgButtonChecked(hDlg,IDC_RADIO4) ? SND_ASYNC : SND_SYNC;
		    	EndDialog(hDlg,TRUE);
			    return (TRUE);
			    break;
			  case IDCANCEL:
					EndDialog(hDlg,FALSE);
			    return (FALSE);
			    break;
			  }  
			break;
		}
	return(FALSE);
  }

LRESULT CALLBACK VocoderDlg(HWND hDlg, unsigned message, WORD wParam, LONG lParam) {
	int x,y,x1,y1;
	RECT dim;

	switch(message) {
		case WM_INITDIALOG:
			CheckRadioButton(hDlg,IDC_RADIO1,IDC_RADIO3,bVocoderMode ? ((bVocoderMode == 1) ? IDC_RADIO2 : IDC_RADIO3) : IDC_RADIO1);
			return (TRUE);

   	case WM_COMMAND:
			switch(wParam) {
			  case IDOK:
	  		  if(IsDlgButtonChecked(hDlg,IDC_RADIO3))
						bVocoderMode=2;
					else if(IsDlgButtonChecked(hDlg,IDC_RADIO2))
						bVocoderMode=1;
					else
						bVocoderMode=0;
		    	EndDialog(hDlg,TRUE);
			    return (TRUE);
			    break;
			  case IDCANCEL:
					EndDialog(hDlg,FALSE);
			    return (FALSE);
			    break;
			  }  
			break;
		}
	return(FALSE);
  }


int CreaEffetti(char *pWav, long l, int mode) {
//  RIFF

  }

int ModificaWave(char *pWavOut, char *pWavIn) {
  register int i,j;
	register char *p,*p1;

	switch(bVocoderMode) {
		case 0:
			p=pWavIn;
			p1=pWavOut;
			i=0;
			j=0;

/*			while(i<FREQUENCY/SAMPLE_ACCU) {
				*p1=*p;
				*(p1+1)=*p;
				*(p1+2)=*(p+1);
				p+=2;
				p1+=3;
				i+=3;
				j++;
				if(j==200) {
					p+=200;
					j=0;
				  }
			  }*/
			while(i<FREQUENCY/SAMPLE_ACCU) {
				*p1=*p;
				*(p1+1)=*p;
				*(p1+2)=*(p+1);
				*(p1+3)=*(p+2);
				p+=3;
				p1+=4;
				i+=4;
				j++;
				if(j==200) {
					p+=200;
					j=0;
				  }
			  }
			break;
		case 1:
			memcpy(pWavOut,pWavIn,FREQUENCY/SAMPLE_ACCU);
			break;
		case 2:
			p=pWavIn;
			p1=pWavOut;
			i=0;
			j=0;
			while(i<FREQUENCY/SAMPLE_ACCU) {
				*p1=*p;
				*(p1+1)=*(p+1);
				*(p1+2)=*(p+2);
				p+=4;
				p1+=3;
				i+=3;
				j++;
				if(j==200) {
					memcpy(p1,p1-200,200);
					p1+=200;
					i+=200;
					j=0;
				  }
			  }
			break;
	  }
  }