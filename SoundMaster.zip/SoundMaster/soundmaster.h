#define FREQUENCY 22050
#define SAMPLE_ACCU 2

