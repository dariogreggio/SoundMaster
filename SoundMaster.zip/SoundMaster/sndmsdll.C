//#include <stdio.h>
#include <windows.h>
#include <mmsystem.h>

HANDLE hInst,hHook;
char myWAVFiles[12][128];
int UseCTRL=0;
int WAVMode;

int CALLBACK LibMain(HANDLE hModule, WORD wDataSeg, WORD cbHeapSize, LPSTR lpszCmdLine) {
	register int i,j;    
	long l;

  return 1;
  }
       
int CALLBACK WEP(int bSystemExit) {

  return 1;
  }
         
int FAR PASCAL HookInit(HANDLE myHook,char WAVFiles[12][256],int nMax,int myWAVMode,int myUseCTRL) {
  int i;
	
	hHook=myHook;
	WAVMode=myWAVMode;
	UseCTRL=myUseCTRL;
	for(i=0; i<nMax; i++)
	  strcpy(myWAVFiles[i],WAVFiles[i]);
  return 1;
  }
       
DWORD FAR PASCAL HookProc(int code, int wParam, long lParam) {

	if(!(lParam & 0x80000000)) {
	  if(UseCTRL && !(lParam & 0x20000000))
	    goto fine;
		if(wParam >= VK_F1 && wParam <= VK_F12)
			sndPlaySound(myWAVFiles[wParam-VK_F1],WAVMode | SND_NODEFAULT);
fine:		
		if(wParam == VK_ESCAPE)
			sndPlaySound(NULL,WAVMode);
		}
//	if(1) {
	return CallNextHookEx(hHook, code, wParam, lParam);
//    }
  }
 
         
int FAR PASCAL WritePrivateProfileInt(char *s, char *s1, int n, char *f) {
  int i;
  char myBuf[16];
  
  wsprintf(myBuf,"%d",n);
  WritePrivateProfileString(s,s1,myBuf,f);
  }

