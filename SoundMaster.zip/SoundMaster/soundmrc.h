//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by soundmaster.rc
//
#define IDS_ABOUTMENU                   1
#define IDI_ICON1                       101
#define AppIcon                         101
#define IDD_DIALOG1                     102
#define IDD_VOCOD_PARMS                 103
#define IDR_ACCELERATOR1                104
#define IDR_MENU1                       105
#define APPICON1                        106
#define SMALL                           107
#define IDS_ABOUT2                      1000
#define IDC_CHECK1                      1001
#define IDC_RADIO1                      1002
#define IDC_RADIO2                      1003
#define IDC_EDIT1                       1004
#define IDC_CHECK2                      1005
#define IDC_EDIT2                       1006
#define IDC_RADIO5                      1007
#define IDC_RADIO3                      1008
#define IDC_RADIO4                      1009
#define IDC_RADIO6                      1010
#define SaveDlg                         1536
#define OpenDlg                         1536
#define ID_FILE_OPEN1                   40001
#define ID_FILE_OPEN2                   40002
#define ID_FILE_OPEN3                   40003
#define ID_FILE_OPEN4                   40004
#define ID_FILE_OPEN5                   40005
#define ID_FILE_OPEN6                   40006
#define ID_FILE_OPEN7                   40007
#define ID_FILE_OPEN8                   40008
#define ID_FILE_OPEN9                   40009
#define ID_FILE_OPEN10                  40010
#define ID_FILE_OPEN11                  40011
#define ID_FILE_OPEN12                  40012
#define ID_SUONA1                       40021
#define ID_SUONA2                       40022
#define ID_SUONA3                       40023
#define ID_SUONA4                       40024
#define ID_SUONA5                       40025
#define ID_SUONA6                       40026
#define ID_SUONA7                       40027
#define ID_SUONA8                       40028
#define ID_SUONA9                       40029
#define ID_SUONA10                      40030
#define ID_SUONA11                      40031
#define ID_SUONA12                      40032
#define ID_FILE_OPZIONI                 40038
#define ID_SUONA99                      40039
#define ID_SUONA_AUTO                   40040
#define ID_FILE_VOLUME                  40041
#define ID_SUONAB1                      40043
#define ID_SUONAB2                      40044
#define ID_SUONAB3                      40045
#define ID_FILE_VOCODERATTIVO           40046
#define ID_VOCODER_PARAMETRI            40047

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40049
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
