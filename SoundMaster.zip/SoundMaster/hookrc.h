//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by soundmaster.rc
//
#define IDD_VOCOD_PARMS                 105

#define IDC_CHECK1                      1001
#define IDC_RADIO1                      1004
#define IDC_EDIT1                      1002
#define IDC_CHECK2                      1003
#define IDC_EDIT2                      1005
#define IDC_RADIO2                      1006
#define IDC_RADIO3                      1007
#define IDC_RADIO4                      1008
#define IDC_RADIO5                      1009
#define IDC_RADIO6                      1010
#define ID_FILE_OPEN1                     1001
#define ID_FILE_OPEN2                     1002
#define ID_FILE_OPEN3                     1003
#define ID_FILE_OPEN4                     1004
#define ID_FILE_OPEN5                     1005
#define ID_FILE_OPEN6                     1006
#define ID_FILE_OPEN7                     1007
#define ID_FILE_OPEN8                     1008
#define ID_FILE_OPEN9                     1009
#define ID_FILE_OPEN10                     1010
#define ID_FILE_OPEN11                    1011
#define ID_FILE_OPEN12                    1012
#define ID_FILE_OPZIONI                    1013
#define ID_FILE_VOCODERATTIVO              1014
#define ID_FILE_VOLUME                     1015
#define ID_SUONA1                      1016
#define ID_SUONA2                      1017
#define ID_SUONA3                      1018
#define ID_SUONA4                      1019
#define ID_SUONA5                      1020
#define ID_SUONA6                      1021
#define ID_SUONA7                      1022
#define ID_SUONA8                      1023
#define ID_SUONA9                      1024
#define ID_SUONA10                     1025
#define ID_SUONA11                     1026
#define ID_SUONA12											1027
#define ID_SUONA99											1028
#define ID_SUONA_AUTO										1029
#define ID_SUONAB1										1030
#define ID_SUONAB2										1031
#define ID_SUONAB3										1032	
#define ID_VOCODER_PARAMETRI					1033
#define IDS_ABOUTMENU									1034

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40048
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
