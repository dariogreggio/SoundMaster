#include <windows.h>
#include <mmsystem.h>
#include "soundmaster.h"
#include "soundmrc.h"

#define NULL 0

DWORD IRecNo,IFirstRecord,ORecNo;
extern HWND hWnd,hStatusBar;
extern HWAVEOUT hWaveOut;
extern HWAVEIN hWaveIn;
extern WAVEHDR *OWaveHdr,*IWaveHdr,*OWaveHdr2,*IWaveHdr2;
extern char buffer[256];
extern LPSTR pMem1r,pMem2r,pMem1p,pMem2p;
extern char *APP_ID;

void CDError(int m, int i, int st) {
  char myBuf[128],myBuf1[32];
  int t,t1;

  if(m) {                  // in realt� non funziona per ripristinare...
    t1=hWaveOut;
    hWaveOut=0;
    }
  else {
    t=hWaveIn;
    hWaveIn=0;
    }  
  waveOutGetErrorText(i,myBuf+2,100);
  *myBuf=st+'0';
  *(myBuf+1)=' ';
  strcpy(myBuf1,APP_ID);
  strcat(myBuf1," - ");
  strcat(myBuf1,m ? "PLAY" : "REC");
  MessageBox(NULL,myBuf,myBuf1,MB_OK);
  if(m) {
    hWaveOut=t1;
    }
  else {
    hWaveIn=t;
    }  
	}  

int outWave(int *PlayNo,int LastPlay,HWAVEOUT hWaveOut,WAVEHDR *OWaveHdr,WAVEHDR *OWaveHdr2,LPSTR p1,LPSTR p2) {
  UINT i;
  int st;
  MSG msg;
  char buffer[128];
	static DWORD ti;

  (*PlayNo)++;
  if(*PlayNo == 1) {
    i=waveOutPrepareHeader(hWaveOut,OWaveHdr,sizeof(WAVEHDR));
	  if(i) {
 		  st=2;
  	  goto CDError;
	    }             
//			  while(!(OWaveHdr->dwFlags & WHDR_PREPARED));
	  i=waveOutWrite(hWaveOut,OWaveHdr,sizeof(WAVEHDR));
	  if(i) {
	    st=3;
	    goto CDError;
	    }   
    i=waveOutPrepareHeader(hWaveOut,OWaveHdr2,sizeof(WAVEHDR));
	  if(i) {
 		  st=2;
  	  goto CDError;
	    }             
//			  while(!(OWaveHdr2->dwFlags & WHDR_PREPARED));
	  i=waveOutWrite(hWaveOut,OWaveHdr2,sizeof(WAVEHDR));
	  if(i) {
	    st=3;
	    goto CDError;
	    }   
	  goto NoCDError;
	  }
	else if(*PlayNo > 1) { 
	
/*	wsprintf(buffer,"segm. %d",*PlayNo);
	SetWindowText(hStatusBar,buffer);
	*/
	
	  if(!(*PlayNo & 1)) {
		  ti=timeGetTime();
      do {
 		    if((OWaveHdr->dwFlags & WHDR_DONE))
  	      break;
        PeekMessage(&msg,NULL,NULL,NULL,PM_NOREMOVE);
        } while(timeGetTime() < (ti+500));
		  i=waveOutUnprepareHeader(hWaveOut,OWaveHdr,sizeof(WAVEHDR));
		  if(i) {
		    st=4;
		    goto CDError;
		    }             
  	  if(LastPlay) {
  	    goto EndMessage;
  	    }
	    i=waveOutPrepareHeader(hWaveOut,OWaveHdr,sizeof(WAVEHDR));
		  if(i) {
  		  st=2;
	  	  goto CDError;
		    }             
//			  while(!(OWaveHdr->dwFlags & WHDR_PREPARED));
		  i=waveOutWrite(hWaveOut,OWaveHdr,sizeof(WAVEHDR));
		  if(i) {
		    st=3;
		    goto CDError;
		    }   
 	  	}
	  else {
		  ti=timeGetTime();
      do {
 		    if((OWaveHdr2->dwFlags & WHDR_DONE))
  	      break;
        PeekMessage(&msg,NULL,NULL,NULL,PM_NOREMOVE);
        } while(timeGetTime() < (ti+500));
		  i=waveOutUnprepareHeader(hWaveOut,OWaveHdr2,sizeof(WAVEHDR));
		  if(i) {
		    st=4;
		    goto CDError;
		    }
  	  if(LastPlay) {
  	    goto EndMessage;
  	    }
	    i=waveOutPrepareHeader(hWaveOut,OWaveHdr2,sizeof(WAVEHDR));
		  if(i) {
  		  st=2;
	  	  goto CDError;
		    }             
//			  while(!(OWaveHdr2->dwFlags & WHDR_PREPARED));
		  i=waveOutWrite(hWaveOut,OWaveHdr2,sizeof(WAVEHDR));
		  if(i) {
		    st=3;
		    goto CDError;
		    }   
	    }
	  }
	goto NoCDError;
		
EndMessage:
  ti=timeGetTime();
  do {
    if((OWaveHdr->dwFlags & WHDR_DONE) && (OWaveHdr2->dwFlags & WHDR_DONE))
      break;
    PeekMessage(&msg,NULL,NULL,NULL,PM_NOREMOVE);
    } while(timeGetTime() < (ti+500));
  goto NoCDError;
        
CDError: 
	  CDError(1,i,st);
		
NoCDError: ;
	return LastPlay;  
  }
  
int inPrepare(int mode, HWAVEIN *hWaveIn) {
  int i,st;
	WAVEFORMATEX IPCMWaveFormat;

	IRecNo=0;
	IFirstRecord=TRUE;
  if(!mode) {
		if(*hWaveIn) {
			i=waveInStop(*hWaveIn);
			if(i) {
				st=4;
				goto CDError;
				}   
			i=waveInClose(*hWaveIn);
			if(i) {
				st=6;
				goto CDError;
				}
			*hWaveIn=0;  
			}
	  return 0;  
	  }  
	else {
		IPCMWaveFormat.wFormatTag=WAVE_FORMAT_PCM;
		IPCMWaveFormat.nChannels=1;
		IPCMWaveFormat.nSamplesPerSec=FREQUENCY;
		IPCMWaveFormat.nAvgBytesPerSec=FREQUENCY;
		IPCMWaveFormat.nBlockAlign=1;
		IPCMWaveFormat.wBitsPerSample=8;
		IPCMWaveFormat.cbSize=0;
	  i=waveInOpen(hWaveIn,WAVE_MAPPER,(LPWAVEFORMATEX)&IPCMWaveFormat,
	    (DWORD)hWnd,NULL,NULL);
	  if(i) {
	    st=1;
	    goto CDError;
	    }          

	  IWaveHdr->lpData=pMem1r;
	  IWaveHdr->dwBufferLength=FREQUENCY/SAMPLE_ACCU;
	  IWaveHdr->dwFlags=0;
	  IWaveHdr->dwLoops=0;
	  IWaveHdr->dwBytesRecorded=0;
	  IWaveHdr->dwUser=0;
	  IWaveHdr->lpNext=NULL;
	  IWaveHdr->reserved=0;
		  
	  *IWaveHdr2=*IWaveHdr;
	  IWaveHdr2->lpData=pMem2r;
		  
	  i=waveInStart(*hWaveIn);
	  if(i) {
	    st=4;
	    goto CDError;
	    }   
	  return 0;  
	  }  

CDError: 
	  CDError(0,i,st);
	  return 1;

  }
  
int outPrepare(int mode, HWAVEOUT *hWaveOut) {
  int i,st;
	WAVEFORMATEX OPCMWaveFormat;

  if(!mode) {
		if(*hWaveOut) {
			i=waveOutReset(*hWaveOut);
			if(i) {
				st=4;
				goto CDError;
				}   
			i=waveOutClose(*hWaveOut);
			if(i) {
				st=6;
				goto CDError;
				}
			*hWaveOut=0;  
			}
	  return 0;  
	  }  
	else {
	  OPCMWaveFormat.wFormatTag=WAVE_FORMAT_PCM;
		OPCMWaveFormat.nChannels=1;
		OPCMWaveFormat.nSamplesPerSec=FREQUENCY;
		OPCMWaveFormat.nAvgBytesPerSec=FREQUENCY;
		OPCMWaveFormat.nBlockAlign=1;
		OPCMWaveFormat.wBitsPerSample=8;
		OPCMWaveFormat.cbSize=0;
	  i=waveOutOpen(hWaveOut,WAVE_MAPPER,(LPWAVEFORMATEX)&OPCMWaveFormat,
	    (DWORD)hWnd,NULL,NULL);
	  if(i) {
	    st=1;
	    goto CDError;
	    }          

	  OWaveHdr->lpData=pMem1p;
	  OWaveHdr->dwBufferLength=FREQUENCY/(SAMPLE_ACCU);
	  OWaveHdr->dwFlags=0;
	  OWaveHdr->dwLoops=0;
	  OWaveHdr->dwBytesRecorded=0;
	  OWaveHdr->dwUser=0;
	  OWaveHdr->lpNext=NULL;
	  OWaveHdr->reserved=0;
		  
	  OWaveHdr2->lpData=pMem2p;
	  OWaveHdr2->dwBufferLength=FREQUENCY/(SAMPLE_ACCU);
	  OWaveHdr2->dwFlags=0;
	  OWaveHdr2->dwLoops=0;
	  OWaveHdr2->dwBytesRecorded=0;
	  OWaveHdr2->dwUser=0;
	  OWaveHdr2->lpNext=NULL;
	  OWaveHdr2->reserved=0;
		  
	  return 0;  
	  }  

CDError: 
	  CDError(1,i,st);
	  return 1;
	
	}
	
int inWave(int *RecNo,int *FirstRecord,HWAVEIN hWaveIn,WAVEHDR *IWaveHdr,WAVEHDR *IWaveHdr2,LPSTR p1,LPSTR p2) {
  UINT i;
  int st;
  MSG msg;
  char buffer[128];
	  
	if(*FirstRecord) {
	  *FirstRecord=FALSE;
	  *RecNo=0;
	  i=waveInPrepareHeader(hWaveIn,IWaveHdr,sizeof(WAVEHDR));
	  if(i) {
	    st=2;
	    goto CDError;
	    }             
	  while(!(IWaveHdr->dwFlags & WHDR_PREPARED));
  	i=waveInAddBuffer(hWaveIn,IWaveHdr,sizeof(WAVEHDR));
		i=waveInPrepareHeader(hWaveIn,IWaveHdr2,sizeof(WAVEHDR));
		if(i) {
		  st=2;
		  goto CDError;
		  }             
		while(!(IWaveHdr2->dwFlags & WHDR_PREPARED));
  	i=waveInAddBuffer(hWaveIn,IWaveHdr2,sizeof(WAVEHDR));
		}
	else {
    if(*RecNo & 1) {
	    i=waveInPrepareHeader(hWaveIn,IWaveHdr,sizeof(WAVEHDR));
		  if(i) {
		    st=2;
		    goto CDError;
		    }             
//		  while(!(IWaveHdr->dwFlags & WHDR_PREPARED));
	    i=waveInAddBuffer(hWaveIn,IWaveHdr,sizeof(WAVEHDR));
	    }
	 	else {
		  i=waveInPrepareHeader(hWaveIn,IWaveHdr2,sizeof(WAVEHDR));
		  if(i) {
		    st=2;
		    goto CDError;
		    }             
//		  while(!(IWaveHdr2->dwFlags & WHDR_PREPARED));
	 	  i=waveInAddBuffer(hWaveIn,IWaveHdr2,sizeof(WAVEHDR));
	 	  }
	  }
	if(i) {
	  st=3;
	  goto CDError;
	  }   
  if(*RecNo & 1) {
	  do {
	    PeekMessage(&msg,NULL,NULL,NULL,PM_NOREMOVE);
	    if((IWaveHdr2->dwFlags & WHDR_DONE))
//	    while(!(IWaveHdr->dwFlags & WHDR_DONE));
	      break;
	    } while(1);  
    }
  else {
  	do {
      PeekMessage(&msg,NULL,NULL,NULL,PM_NOREMOVE);
	    if((IWaveHdr->dwFlags & WHDR_DONE))
	      break;
	    } while(1);  
	  }
  if(*RecNo & 1) {
 	  i=waveInUnprepareHeader(hWaveIn,IWaveHdr2,sizeof(WAVEHDR));
 	  }
  else {
 	  i=waveInUnprepareHeader(hWaveIn,IWaveHdr,sizeof(WAVEHDR));
 	  }
  if(i) {
    st=5;
    goto CDError;
    }             
  (*RecNo)++;
	    
  goto NoCDError;  
	    
CDError: 
	  CDError(0,i,*RecNo);
	    
NoCDError:
  return 0;
  }
  


